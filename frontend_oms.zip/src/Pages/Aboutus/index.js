import '../CSS/index.css'
import Navigationbar from '../../Components/Naviagationbar'
const Aboutus = () =>{
  
    return (
        <div>
            {/* Navigation bar */}
            <Navigationbar />
            <br />
            <div>
                <h3>About our Glourious History</h3>
                <p>
                    Describe Web site
                    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard 
                    dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. 
                    It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.
                    Describe Web site
                    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard 
                    dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. 
                    It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.
                </p>
                <h3>1914 translation by H. Rackham</h3>
                <p>
                    On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized by 
                    the charms of pleasure of the moment, so blinded by desire, that they cannot foresee the pain and trouble that are 
                    bound to ensue; and equal blame belongs to those who fail in their duty through weakness of will, which is the same as 
                    saying through shrinking from toil and pain. These cases are perfectly simple and easy to distinguish. In a free hour, 
                    when our power of choice is untrammelled and when nothing prevents our being able to do what we like best, every pleasure 
                    is to be welcomed and every pain avoided. But in certain circumstances and owing to the claims of duty or the obligations of 
                    business it will frequently occur that pleasures have to be repudiated and annoyances accepted. The wise man therefore always 
                    holds in these matters to this principle of selection: he rejects pleasures to secure other greater pleasures, or else he 
                    endures pains to avoid worse pains.
                </p>
            </div>
        </div>
    )
}

export default Aboutus