MDB 5 React

Version: FREE 2.3.0

Documentation:
https://mdbootstrap.com/docs/b5/react/

Installation:
https://mdbootstrap.com/docs/b5/react/getting-started/installation/

CLI & hosting:
https://mdbootstrap.com/docs/standard/cli/

Support:
https://mdbootstrap.com/support/cat/react/
